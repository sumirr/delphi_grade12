
package Vraag2Package;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Student {

    private String naam;
    private String regKode;
    private String vervalDatum;
    private int sessiesVoltooi;

    // Vraag 2.1.1
    private String bepaalVervalDatum(String regDatum) {
       int jaar = Integer.parseInt(regDatum.substring(0, 4));
       jaar = jaar + 2;

       String expDate = jaar + regDatum.substring(4);
       return vervalDatum;
    }

    // Vraag 2.1.2
    public Student(String naam, String regKode, String regDatum) {
        this.naam = naam;
        this.regKode = regKode;
        vervalDatum = bepaalVervalDatum(regDatum);
        sessiesVoltooi = 0;
    }

    // Vraag 2.1.4
    public void vermeerderSessiesVoltooi() {
        sessiesVoltooi++;
    }

    // Vraag 2.1.3
    public void setSessiesVoltooi(int counter) {
        sessiesVoltooi = counter;
    }

    // Vraag 2.1.5
    public String evalueerVordering(int totaal) {
        double persent = (sessiesVoltooi / (double) totaal) * 100;
        if (persent > 75) {
            return (naam + " kwalifiseer as 'n instrukteur");
        } else {
            return ("Vordering: " + String.format("%-2.0f", persent) + "% is voltooi");
        }
    }

    // Vraag 2.1.6
    public String toString() {
        return (naam + "  [" + regKode + "]\n" + "Vervaldatum: " + vervalDatum + "\nVoltooide sessies: " + sessiesVoltooi);
    }
    
        
    public String getNaam() {
        return naam;
    }

    public String getKode() {
        return regKode;
    }

}
