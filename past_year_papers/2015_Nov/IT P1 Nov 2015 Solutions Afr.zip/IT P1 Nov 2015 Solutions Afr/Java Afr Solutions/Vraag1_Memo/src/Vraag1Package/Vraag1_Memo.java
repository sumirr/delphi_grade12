/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Vraag1Package;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author pc2
 */
public class Vraag1_Memo extends javax.swing.JFrame {

    String[] arrLidKodes = new String[20];


    public void vulLidKodes() {
    arrLidKodes[0] = "PRTHNMM-M-421";
    arrLidKodes[1] = "LYYHNBB-V-623*";
    arrLidKodes[2] = "DFGQWJJK-M-220*";
    arrLidKodes[3] = "NBVGTYY-V-926";
    arrLidKodes[4] = "NBGTRFSSD-V-322*";
    arrLidKodes[5] = "NJKYTRRTG-M-928";
    arrLidKodes[6] = "JBHGTYGFTR-V-121";
    arrLidKodes[7] = "HGTYRJJ-V-522*";
    arrLidKodes[8] = "KJHYTGFDDRWQ-M-830";
    arrLidKodes[9] = "NHYTRFDDD-M-221*";
    arrLidKodes[10] = "NBVGTYYGHG-M-424";
    arrLidKodes[11] = "CVBGFRXXS-M-726";
    arrLidKodes[12] = "PLIUYHGTRF-M-323";
    arrLidKodes[13] = "QWDFGENBG-M-423*";
    arrLidKodes[14] = "RBRTHNDRKS-V-525";
    arrLidKodes[15] = "MKJHTGFDD-M-625";
    arrLidKodes[16] = "SDWRQWDDG-V-726";
    arrLidKodes[17] = "HNGBBVFFDCCS-V-931";
    arrLidKodes[18] = "NMBGHFDRLP-V-121";
    arrLidKodes[19] = "BVCZZXGFDJK-M-122";
    }


    public Vraag1_Memo() {
        initComponents();
        this.setLocationRelativeTo(this);
        vulLidKodes();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        txfLengte = new javax.swing.JTextField();
        txfGewig = new javax.swing.JTextField();
        lblHeight = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txaAfvoer_1_1 = new javax.swing.JTextArea();
        btnVraag1_1 = new javax.swing.JButton();
        lblStartWeight = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        btnVraag1_2 = new javax.swing.JButton();
        lblDoelgewig = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txaAfvoer_1_2 = new javax.swing.JTextArea();
        txfDoelGewig = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        txfLidmaatskapNommer = new javax.swing.JTextField();
        btnVraag1_3 = new javax.swing.JButton();
        lblLidmaatskapNommer = new javax.swing.JLabel();
        lblNaam = new javax.swing.JLabel();
        txfNaam = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        rbnManlik = new javax.swing.JRadioButton();
        rbnVroulik = new javax.swing.JRadioButton();
        jPanel7 = new javax.swing.JPanel();
        chbAllergie = new javax.swing.JCheckBox();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txaAfvoer_1_5 = new javax.swing.JTextArea();
        btnVraag1_5 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        btnVraag1_4 = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        txaAfvoer_1_4 = new javax.swing.JTextArea();
        jPanel8 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Vraag 1.1", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 0, 12))); // NOI18N

        txfLengte.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txfLengte.setText(" ");
        txfLengte.setCaretPosition(0);

        txfGewig.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txfGewig.setText(" ");
        txfGewig.setCaretPosition(0);

        lblHeight.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblHeight.setText("Sleutel lengte in (m)");

        txaAfvoer_1_1.setColumns(20);
        txaAfvoer_1_1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txaAfvoer_1_1.setRows(5);
        jScrollPane1.setViewportView(txaAfvoer_1_1);

        btnVraag1_1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnVraag1_1.setText("Vraag 1.1");
        btnVraag1_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVraag1_1ActionPerformed(evt);
            }
        });

        lblStartWeight.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblStartWeight.setText("Sleutel huidige gewig in (kg)");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lblStartWeight)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txfGewig, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblHeight)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txfLengte, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnVraag1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txfGewig, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblStartWeight))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblHeight)
                        .addComponent(txfLengte, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                        .addComponent(btnVraag1_1)
                        .addGap(24, 24, 24))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Vraag 1.2", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 0, 12))); // NOI18N

        btnVraag1_2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnVraag1_2.setText("Vraag 1.2");
        btnVraag1_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVraag1_2ActionPerformed(evt);
            }
        });

        lblDoelgewig.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblDoelgewig.setText("Sleutel doelgewig in (kg)");

        txaAfvoer_1_2.setColumns(20);
        txaAfvoer_1_2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txaAfvoer_1_2.setRows(5);
        jScrollPane2.setViewportView(txaAfvoer_1_2);

        txfDoelGewig.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txfDoelGewig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txfDoelGewigActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(lblDoelgewig, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txfDoelGewig, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnVraag1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDoelgewig)
                    .addComponent(txfDoelGewig, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnVraag1_2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Vraag 1.3", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 0, 12))); // NOI18N

        txfLidmaatskapNommer.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        btnVraag1_3.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnVraag1_3.setText("Vraag 1.3");
        btnVraag1_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVraag1_3ActionPerformed(evt);
            }
        });

        lblLidmaatskapNommer.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblLidmaatskapNommer.setText("Lidmaatskapkode");

        lblNaam.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblNaam.setText("Sleutel naam in");

        txfNaam.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Selekteer geslag"));
        jPanel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        buttonGroup1.add(rbnManlik);
        rbnManlik.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        rbnManlik.setText("Manlik");

        buttonGroup1.add(rbnVroulik);
        rbnVroulik.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        rbnVroulik.setText("Vroulik");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(rbnVroulik)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rbnManlik)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbnVroulik)
                    .addComponent(rbnManlik))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Merk die blokkie as lid 'n allergie het"));
        jPanel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        chbAllergie.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        chbAllergie.setText("Allergie");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(chbAllergie)
                .addContainerGap(137, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(chbAllergie)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(lblLidmaatskapNommer)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(lblNaam, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txfNaam, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnVraag1_3, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txfLidmaatskapNommer)
                                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNaam)
                    .addComponent(txfNaam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnVraag1_3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLidmaatskapNommer)
                    .addComponent(txfLidmaatskapNommer, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Vraag 1.5", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 0, 12))); // NOI18N

        txaAfvoer_1_5.setColumns(20);
        txaAfvoer_1_5.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txaAfvoer_1_5.setRows(5);
        jScrollPane3.setViewportView(txaAfvoer_1_5);

        btnVraag1_5.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnVraag1_5.setText(" Vraag 1.5");
        btnVraag1_5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVraag1_5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnVraag1_5, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(btnVraag1_5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Vraag 1.4", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 0, 12))); // NOI18N

        btnVraag1_4.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnVraag1_4.setText("Vraag 1.4");
        btnVraag1_4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVraag1_4ActionPerformed(evt);
            }
        });

        txaAfvoer_1_4.setColumns(20);
        txaAfvoer_1_4.setRows(5);
        jScrollPane4.setViewportView(txaAfvoer_1_4);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnVraag1_4, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(btnVraag1_4)
                .addContainerGap(37, Short.MAX_VALUE))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel8.setBackground(new java.awt.Color(153, 153, 153));
        jPanel8.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("                Eagle Star Gym Gewigsverliesprogram");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 649, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
// Vraag  1.1
    private void btnVraag1_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVraag1_1ActionPerformed
        double beginGewig = Double.parseDouble(txfGewig.getText());
        double lengte = Double.parseDouble(txfLengte.getText());
        double bmi = beginGewig / (lengte * lengte);
        String sBmi = String.format("%8.5f",bmi);
        txaAfvoer_1_1.setText("BMI = " + sBmi + "\n");
        if (bmi < 18.5) {
            txaAfvoer_1_1.append("Ondergewig");
        } else if (bmi < 25) {
            txaAfvoer_1_1.append("Normale gewig");
        } else {
            txaAfvoer_1_1.append("Oorgewig");
        }
    }//GEN-LAST:event_btnVraag1_1ActionPerformed
// Vraag 1.2
    private void btnVraag1_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVraag1_2ActionPerformed
        int getalDae = 0;
        double beginGewig = Double.parseDouble(txfGewig.getText());
        double doelGewig = Double.parseDouble(txfDoelGewig.getText());
        if (beginGewig > doelGewig) {
            txaAfvoer_1_2.setText("Dag\tGewig\n");
            while (doelGewig < beginGewig) {
                getalDae++;
                beginGewig -= 0.375;
                txaAfvoer_1_2.append(getalDae + "\t" + String.format("%6.3f",beginGewig) + "\n");
            }
        } else {
            txaAfvoer_1_2.setText("Ongeldige waarde is ingesleutel");
        }
    }//GEN-LAST:event_btnVraag1_2ActionPerformed
// Vraag 1.3
    private void btnVraag1_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVraag1_3ActionPerformed
        String naam = txfNaam.getText().toUpperCase();
        // lidmaatskapKode = lidmaatskapKode.replaceAll("[AEIOU ]", "");

        String lidmaatskapKode = "";
        for (int i = 0; i < naam.length(); i++) {
            if (naam.charAt(i) != 'A' && naam.charAt(i) != 'E' && naam.charAt(i) != 'I'
                    && naam.charAt(i) != 'O' && naam.charAt(i) != 'U' && naam.charAt(i) != ' ') {
                lidmaatskapKode += naam.charAt(i);
            }
        }
        int getalKarak = lidmaatskapKode.length();
        
        if (rbnVroulik.isSelected()) {
            lidmaatskapKode += "-V-";
        }
        if (rbnManlik.isSelected()) {
            lidmaatskapKode += "-M-";
        }

        int randGetal = (int)(Math.random() * 9) + 1;
        lidmaatskapKode = lidmaatskapKode +  randGetal + (randGetal + 10 + getalKarak);

        if (chbAllergie.isSelected()) {
            lidmaatskapKode += '*';
        }

        txfLidmaatskapNommer.setText(lidmaatskapKode);
    }//GEN-LAST:event_btnVraag1_3ActionPerformed
// Vraag 1.4
    private void btnVraag1_4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVraag1_4ActionPerformed
        int randomGetal1 = (int) (Math.random() * 20);
        String geslag = "-M-";
        if (arrLidKodes[randomGetal1].contains("-V-")) {
            geslag = "-V-";
        }

        int randomGetal2;

        do {
            randomGetal2 = (int) (Math.random() * 20);
        } while (arrLidKodes[randomGetal2].contains(geslag));

        txaAfvoer_1_4.setText("Premium lede\n================");
        txaAfvoer_1_4.append("\n" + arrLidKodes[randomGetal1]);
        txaAfvoer_1_4.append("\n" + arrLidKodes[randomGetal2]);
    }//GEN-LAST:event_btnVraag1_4ActionPerformed
// Vraag 1.5
    private void btnVraag1_5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVraag1_5ActionPerformed

        for (int i = 0; i < 19; i++) {
            for (int j = i + 1; j < 20; j++) {

                if ((arrLidKodes[i]).compareTo(arrLidKodes[j]) > 0) {
                    String temp = arrLidKodes[i];
                    arrLidKodes[i] = arrLidKodes[j];
                    arrLidKodes[j] = temp;
                }
            }
        }


        for (int i = 0; i < 20; i++) {
            if (arrLidKodes[i].contains("*")) {
                txaAfvoer_1_5.append(arrLidKodes[i] + "\n");
            }
        }

        for (int i = 0; i < 20; i++) {

            if (!arrLidKodes[i].contains("*")) {
                txaAfvoer_1_5.append(arrLidKodes[i] + "\n");
            }
        }




    }//GEN-LAST:event_btnVraag1_5ActionPerformed

    private void txfDoelGewigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txfDoelGewigActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txfDoelGewigActionPerformed
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;






                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vraag1_Memo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vraag1_Memo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vraag1_Memo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vraag1_Memo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vraag1_Memo().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVraag1_1;
    private javax.swing.JButton btnVraag1_2;
    private javax.swing.JButton btnVraag1_3;
    private javax.swing.JButton btnVraag1_4;
    private javax.swing.JButton btnVraag1_5;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JCheckBox chbAllergie;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel lblDoelgewig;
    private javax.swing.JLabel lblHeight;
    private javax.swing.JLabel lblLidmaatskapNommer;
    private javax.swing.JLabel lblNaam;
    private javax.swing.JLabel lblStartWeight;
    private javax.swing.JRadioButton rbnManlik;
    private javax.swing.JRadioButton rbnVroulik;
    private javax.swing.JTextArea txaAfvoer_1_1;
    private javax.swing.JTextArea txaAfvoer_1_2;
    private javax.swing.JTextArea txaAfvoer_1_4;
    private javax.swing.JTextArea txaAfvoer_1_5;
    private javax.swing.JTextField txfDoelGewig;
    private javax.swing.JTextField txfGewig;
    private javax.swing.JTextField txfLengte;
    private javax.swing.JTextField txfLidmaatskapNommer;
    private javax.swing.JTextField txfNaam;
    // End of variables declaration//GEN-END:variables
}
