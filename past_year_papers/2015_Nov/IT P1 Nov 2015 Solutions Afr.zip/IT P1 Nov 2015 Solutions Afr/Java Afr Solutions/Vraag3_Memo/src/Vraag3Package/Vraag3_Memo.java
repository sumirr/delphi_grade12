package Vraag3Package;

import javax.swing.JOptionPane;

public class Vraag3_Memo extends javax.swing.JFrame {

    String[] arrWerkswinkels = {"Aerobics", "Liggaamsbou", "Kardio", "Dans", "Energieaanvullings", "Eerstehulp"};
    int[][] arrBywoning = {{11, 14, 5, 14}, {15, 5, 20, 4}, {10, 14, 16, 20}, {20, 20, 20, 20}, {16, 7, 10, 7}, {10, 18, 13, 11}};
    int getalWerkswinkels = 6;

    public Vraag3_Memo() {
        initComponents();
        this.setLocationRelativeTo(this);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cmbWerkswinkels = new javax.swing.JComboBox();
        lblKiesDag = new javax.swing.JLabel();
        lblKiesOnderwerp = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        lstDae = new javax.swing.JList();
        lblDag = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        btnKanselleer = new javax.swing.JButton();
        btnWater = new javax.swing.JButton();
        btnBespreking = new javax.swing.JButton();
        btnVertoon = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txaAfvoer = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Toevoer van gebruiker:"));
        jPanel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel1.setText("Selekteer die werkswinkel wat jy wil bespreek");

        cmbWerkswinkels.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        cmbWerkswinkels.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Aerobics", "Liggaamsbou", "Kardio", "Dans", "Energieaanvullings", "Eerstehulp", " " }));

        lblKiesDag.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblKiesDag.setText("Dag:");

        lblKiesOnderwerp.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblKiesOnderwerp.setText("Werkswinkel:");

        lstDae.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Dag 1", "Dag 2", "Dag 3", "Dag 4", " " };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(lstDae);

        lblDag.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblDag.setText("Selekteer die dag waarop jy die werkswinkel wil bywoon");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblKiesOnderwerp)
                            .addComponent(lblKiesDag))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(cmbWerkswinkels, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(lblDag))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbWerkswinkels, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblKiesOnderwerp))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblDag)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblKiesDag))
                .addContainerGap())
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Additionele komponente:"));

        btnKanselleer.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnKanselleer.setText("Kanselleer 'n werkswinkel");
        btnKanselleer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKanselleerActionPerformed(evt);
            }
        });

        btnWater.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnWater.setText("Watervereistes");
        btnWater.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWaterActionPerformed(evt);
            }
        });

        btnBespreking.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBespreking.setText("Doen 'n bespreking");
        btnBespreking.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBesprekingActionPerformed(evt);
            }
        });

        btnVertoon.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnVertoon.setText("Vertoon ");
        btnVertoon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVertoonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(58, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnKanselleer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnWater, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnBespreking, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnVertoon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(58, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnVertoon, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBespreking, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnWater, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
                .addGap(11, 11, 11)
                .addComponent(btnKanselleer, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Afvoerarea:"));
        jPanel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        txaAfvoer.setColumns(20);
        txaAfvoer.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        txaAfvoer.setRows(5);
        txaAfvoer.setBorder(null);
        jScrollPane3.setViewportView(txaAfvoer);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 546, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 4, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
// Display array with headings - call method vertoon
    private void btnVertoonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVertoonActionPerformed
        vertoon();
    }//GEN-LAST:event_btnVertoonActionPerformed
// Make a booking
    private void btnBesprekingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBesprekingActionPerformed
        String werkswinkel = cmbWerkswinkels.getSelectedItem().toString();
        int dag = lstDae.getSelectedIndex() + 1;

        String boodskap = "";

        for (int r = 0; r < getalWerkswinkels; r++) {
            if (werkswinkel.equals(arrWerkswinkels[r])) {

                for (int c = 0; c < 4; c++) {
                    if (dag == (c + 1)) {
                        if (arrBywoning[r][c] < 20) {
                            arrBywoning[r][c] = arrBywoning[r][c] + 1;
                            vertoon();
                            JOptionPane.showMessageDialog(null, werkswinkel + " op dag " + dag + " is suksesvol bespreek");

                        } else {
                            JOptionPane.showMessageDialog(null, werkswinkel + " op dag " + dag + " is volledig bgespreek");
                        }
                    }
                }
            }
        }

    }//GEN-LAST:event_btnBesprekingActionPerformed
// Bereken getal kaste water
    private void btnWaterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWaterActionPerformed
        int bottels[] = new int[4];
        int totaleBottels = 0;
        int kaste = 0;

        for (int c = 0; c < 4; c++) {
            for (int r = 0; r < getalWerkswinkels; r++) {

                bottels[c] = bottels[c] + arrBywoning[r][c];
            }
            totaleBottels = totaleBottels + bottels[c];
        }
        txaAfvoer.setText("\nBottels water wat benodig word\n");
        for (int r = 0; r < 4; r++) {
            txaAfvoer.append(String.format("Dag %-25s%-10s\n", (r + 1), bottels[r]));
        }

        double antwoord = totaleBottels % 24;
        if (antwoord == 0) {
            kaste = totaleBottels / 24;
        } else {
            kaste = (totaleBottels / 24) + 1;
        }

        txaAfvoer.append(String.format("\n%-28s%-10s", "Totaal: ", totaleBottels));

        txaAfvoer.append(String.format("\n%-28s%-10s", "Kastewater wat benodig word: ", kaste));
    }//GEN-LAST:event_btnWaterActionPerformed
// Kanselleer 'n werkswinkel
    private void btnKanselleerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKanselleerActionPerformed

        int werkswinkelNom = cmbWerkswinkels.getSelectedIndex();
        cmbWerkswinkels.removeItemAt(werkswinkelNom);


        for (int i = werkswinkelNom; i < getalWerkswinkels - 1; i++) {
            arrWerkswinkels[i] = arrWerkswinkels[i + 1];
        }
        arrWerkswinkels[5] = "";
        for (int r = werkswinkelNom; r < getalWerkswinkels - 1; r++) {
            for (int c = 0; c < 4; c++) {
                arrBywoning[r][c] = arrBywoning[r + 1][c];
            }

        }

        getalWerkswinkels--;
        vertoon();

    }//GEN-LAST:event_btnKanselleerActionPerformed
// Metode om 2-dimensionele skikking met opskrifte te vertoon
    public void vertoon() {
        txaAfvoer.setText(String.format("%-25s", "Werkswinkel"));
        for (int i = 1; i <= 4; i++) {
            txaAfvoer.append(String.format("%-10s", "Dag " + i));
        }
        txaAfvoer.append("\n\n");
        for (int r = 0; r < getalWerkswinkels; r++) {

            txaAfvoer.append(String.format("%-25s", arrWerkswinkels[r]));
            for (int c = 0; c < 4; c++) {

                txaAfvoer.append(String.format("%-10s", arrBywoning[r][c]));

            }
            txaAfvoer.append("\n");
        }
        txaAfvoer.append("\n");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vraag3_Memo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vraag3_Memo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vraag3_Memo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vraag3_Memo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and vertoon the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vraag3_Memo().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBespreking;
    private javax.swing.JButton btnKanselleer;
    private javax.swing.JButton btnVertoon;
    private javax.swing.JButton btnWater;
    private javax.swing.JComboBox cmbWerkswinkels;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblDag;
    private javax.swing.JLabel lblKiesDag;
    private javax.swing.JLabel lblKiesOnderwerp;
    private javax.swing.JList lstDae;
    private javax.swing.JTextArea txaAfvoer;
    // End of variables declaration//GEN-END:variables
}
