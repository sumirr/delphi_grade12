package TestQuestion2_GUI;

// Type your examination number here...

public class DanceCouple {
    private String dance_p1;
    private String dance_p2;
    private char professional;

    public DanceCouple()
    {

    }

    public String getDancePartner1()
    {
            return dance_p1;
    }

    public String getDancePartner2()
    {
            return dance_p2;
    }

    public char getProfessional()
    {
            return professional;
    }

}
