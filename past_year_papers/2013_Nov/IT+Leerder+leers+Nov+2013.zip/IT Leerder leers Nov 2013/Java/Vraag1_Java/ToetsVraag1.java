// Sleutel jou eksamennommer hier in.

   import java.io.BufferedReader;
   import java.io.InputStreamReader;
   import java.io.IOException;
   import java.sql.*;
   import java.util.Scanner;

    public class ToetsVraag1 
	 {
       public static void main(String[] args) throws SQLException, IOException {

	      Scanner sc = new Scanner(System.in);
         // OF 
			// BufferedReader inKb = new BufferedReader(new InputStreamReader(System.in));

         Vraag1 DB = new Vraag1();
         System.out.println();
      
         char keuse = ' ';
         do {
            System.out.println("\n\n      KEUSELYS");
            System.out.println();
            System.out.println("    Opsie A");
            System.out.println("    Opsie B");
            System.out.println("    Opsie C");
            System.out.println("    Opsie D");
            System.out.println("    Opsie E");
            System.out.println("    Opsie F");
            System.out.println("    Opsie G");
            System.out.println();
            System.out.println("    V - VERLAAT");
            System.out.println(" ");
            System.out.print("    Jou keuse? ");
            keuse = sc.nextLine().toUpperCase().charAt(0);
	         // OF
	         // keuse = inKb.readLine().toUpperCase().charAt(0);
            System.out.println(" ");
            String sql = "";
            switch (keuse) {
               case 'A': // Vraag 1.1
                  {
                     sql = "";                  
                     DB.query(sql);
                     break;
                  }
                //=============================================================================
               case 'B': // Vraag 1.2
                  {
                     sql = "";
                     DB.query(sql);
                     break;
                  }
                //=============================================================================
               case 'C': // Vraag 1.3
                  {
                     System.out.println("Vraag 1:");
                     String sX = sc.nextLine();
                     // OF 
		               // String sX = inKb.readLine();
                     sql = "";                  
                     DB.query(sql);
                     break;
                  }
                //=============================================================================
               case 'D': // Vraag 1.4
                  {
                     sql = "";                  
                     DB.query(sql);
                     break;
                  }
                //=============================================================================
               case 'E': // Vraag 1.5
                  {
                     sql = "";                  
                     DB.query(sql);                 
                     break;
                  }
                //=============================================================================
               case 'F': // Vraag 1.6
                  {
                     sql = "";                  
                     DB.query(sql);
                     break;
                  }
                //=============================================================================
               case 'G': // Vraag 1.7				
                  {
                     sql = "";
                     DB.query(sql);
                     break;
                  }            
            }
         } while (keuse != 'V');
         DB.disconnect();
         System.out.println("Verlaat");
      }
   }
