// Sleutel jou eksamennommer hier in.

   import java.io.*;
   import javax.swing.*;
   import java.text.*;
   import java.util.Scanner;
	
    public class ToetsVraag2 
	 {
		
      public static void main(String[] args) throws Exception 
      {
         Scanner sc = new Scanner(System.in);
         //OF BufferedReader kb = new BufferedReader(new InputStreamReader(System.in));
			 
         char keuse = ' ';
         do {
            System.out.println("   KEUSELYS\n");
            System.out.println("Opsie A");
            System.out.println("Opsie B");
				System.out.println("Opsie C");				
            System.out.println("");
            System.out.println("V - VERLAAT");
            System.out.println("\nJou keuse?  ");
         
	         keuse = sc.nextLine().toUpperCase().charAt(0);
            //OF keuse = kb.readLine().toUpperCase().charAt(0);
            switch (keuse) {
               case 'A':
					// Kodeer Opsie A
			
                  break;
               case 'B':
					// Kodeer Opsie B
							
                  break;
               case 'C':
					// Kodeer opsie C

                  break;												
               case 'V':
                  System.out.println("VERLAAT");
            }
         } while (keuse != 'V');      
      }          
    }