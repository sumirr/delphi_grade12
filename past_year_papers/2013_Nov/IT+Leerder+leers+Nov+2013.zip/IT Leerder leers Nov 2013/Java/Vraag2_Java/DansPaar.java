// Sleutel jou eksamennommer hier in.

public class DansPaar
{
	private String dans_m1;
	private String dans_m2;
	private char professioneel;

	public DansPaar()
	{
	
	}
	
	public String getDansMaat1()
	{
		return dans_m1;
	}
	
	public String getDansMaat2()
	{
		return dans_m2;
	}
	
	public char getProfessioneel()
	{
		return professioneel;
	}

}