/*
 * Oplossing vir Vraag 2
 */
package Vraag2Package;

import java.text.DecimalFormat;

public class HuisLening {

    private String aansoekerNaam;
    private double besteebareInkomste;
    private double leningBedrag;
    private int jare;
    private double renteKoers;
    
    DecimalFormat df = new DecimalFormat("R 0.00");

    public HuisLening(String aansoekerNaam, double besteebareInkomste, double leningBedrag) {
        this.aansoekerNaam = aansoekerNaam;
        this.besteebareInkomste = besteebareInkomste;
        this.leningBedrag = leningBedrag;
        this.jare = 0;
        this.renteKoers = 0;
    }

    public String getAansoekerNaam() {
        return aansoekerNaam;
    }    
    
    public void setJare(int jare) {
        this.jare = jare;
    }

    public void setRenteKoers(double renteKoers) {
        this.renteKoers = renteKoers;
    }

    public double berekenPaaiement() {
        double paaiement, koers;
        int result;
        koers = renteKoers / 100.0;
        paaiement = (koers * leningBedrag) / (1 - ((Math.pow((1 + koers), (jare * -1)))));
        result = (int) (Math.round(paaiement / 12));
        return result;
    }

    public boolean isGoedgekeur() {
        boolean goedgekeur = true;
        if (leningBedrag > 800000 && jare < 25) {
            goedgekeur = false;
        }
        if (leningBedrag <= 600000) {
            if (besteebareInkomste < (berekenPaaiement() * 1.3)) {
                goedgekeur = false;
            }            
        }
        return goedgekeur;
    }

    public String toString() {
        String afvoer = "Naam van aansoeker: "+aansoekerNaam+"\nBesteebare inkomste: " + df.format(besteebareInkomste) +"\nLeningbedrag: " + df.format(leningBedrag) + "\nGetal jare: " + jare + "\nRentekoers: " + renteKoers;
        return afvoer;
    }
}
