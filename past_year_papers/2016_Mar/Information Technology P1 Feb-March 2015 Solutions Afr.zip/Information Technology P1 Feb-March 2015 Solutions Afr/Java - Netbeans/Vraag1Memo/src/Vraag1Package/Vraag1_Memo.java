package Vraag1Package;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class Vraag1_Memo extends javax.swing.JFrame {

    DecimalFormat df = new DecimalFormat("R 0.00");
   
    char opknappingsTipe = ' ';
    double eletrRekening;

    public Vraag1_Memo() {

        initComponents();
        this.setLocationRelativeTo(this);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        tbpQuestion1 = new javax.swing.JTabbedPane();
        pnlVr1_1 = new javax.swing.JPanel();
        pnlAdvertisement = new javax.swing.JPanel();
        txfMarkwaarde = new javax.swing.JTextField();
        lblAantalBadkamers = new javax.swing.JLabel();
        chkSwembad = new javax.swing.JCheckBox();
        lblVerkoopsprys = new javax.swing.JLabel();
        btnVerkoopsAdv = new javax.swing.JButton();
        txfVerkoopsprys = new javax.swing.JTextField();
        lblAantalSlaapkamers = new javax.swing.JLabel();
        txfBadkamers = new javax.swing.JTextField();
        txfBeddens = new javax.swing.JTextField();
        lblMarkwaarde = new javax.swing.JLabel();
        pnlAdOutput = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txaAfvoer = new javax.swing.JTextArea();
        pnlVr1_2 = new javax.swing.JPanel();
        pnlMetodeOpknapping = new javax.swing.JPanel();
        rbtVerf = new javax.swing.JRadioButton();
        rbtTeel = new javax.swing.JRadioButton();
        btnBerekOpknapping = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txaAfvoerOpknapping = new javax.swing.JTextArea();
        pnlOppvToevoer = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        lblOppvOpknap = new javax.swing.JLabel();
        txfOppervlakte = new javax.swing.JTextField();
        pnlQ1_3 = new javax.swing.JPanel();
        pnlBerekenElekt = new javax.swing.JPanel();
        lblElektrisiteit = new javax.swing.JLabel();
        lblVorigeLesing = new javax.swing.JLabel();
        lblHuidigeLesing = new javax.swing.JLabel();
        txfHudige = new javax.swing.JTextField();
        txfVorige = new javax.swing.JTextField();
        lblOpskrifKiloW = new javax.swing.JLabel();
        lblBedragVerskuldig = new javax.swing.JLabel();
        btnBerekenBedrag = new javax.swing.JButton();
        pnlGeiserOpsies = new javax.swing.JPanel();
        txfGeiserGrootte = new javax.swing.JTextField();
        lblGeiserGroottes = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txaAfvoerGeisers = new javax.swing.JTextArea();
        btnVindGeisers = new javax.swing.JButton();
        btnClose = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Vraag 1 - Algemene probleemoplossing (Memo)");

        tbpQuestion1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tbpQuestion1.setName("Question1"); // NOI18N

        txfMarkwaarde.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txfMarkwaarde.setText("0");

        lblAantalBadkamers.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblAantalBadkamers.setText("Getal badkamers:");

        chkSwembad.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        chkSwembad.setText("Swembad");

        lblVerkoopsprys.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblVerkoopsprys.setText("Verkoopsprys:");

        btnVerkoopsAdv.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnVerkoopsAdv.setText("Genereer advertensie");
        btnVerkoopsAdv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerkoopsAdvActionPerformed(evt);
            }
        });

        txfVerkoopsprys.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txfVerkoopsprys.setText("0");

        lblAantalSlaapkamers.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblAantalSlaapkamers.setText("Getal slaapkamers:");

        txfBadkamers.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txfBadkamers.setText("0");

        txfBeddens.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txfBeddens.setText("0");

        lblMarkwaarde.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblMarkwaarde.setText("Markwaarde:");

        javax.swing.GroupLayout pnlAdvertisementLayout = new javax.swing.GroupLayout(pnlAdvertisement);
        pnlAdvertisement.setLayout(pnlAdvertisementLayout);
        pnlAdvertisementLayout.setHorizontalGroup(
            pnlAdvertisementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAdvertisementLayout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addComponent(btnVerkoopsAdv, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 120, Short.MAX_VALUE))
            .addGroup(pnlAdvertisementLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addGroup(pnlAdvertisementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblVerkoopsprys, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblMarkwaarde, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAantalSlaapkamers, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAantalBadkamers, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(pnlAdvertisementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(chkSwembad)
                    .addComponent(txfVerkoopsprys, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txfMarkwaarde, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txfBeddens, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txfBadkamers, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlAdvertisementLayout.setVerticalGroup(
            pnlAdvertisementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAdvertisementLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlAdvertisementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMarkwaarde, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txfMarkwaarde, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlAdvertisementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txfVerkoopsprys, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblVerkoopsprys, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlAdvertisementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txfBeddens, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAantalSlaapkamers, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlAdvertisementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAantalBadkamers, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txfBadkamers, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(chkSwembad)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addComponent(btnVerkoopsAdv, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlAdOutput.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Advertensie", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N

        txaAfvoer.setColumns(20);
        txaAfvoer.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txaAfvoer.setRows(5);
        jScrollPane1.setViewportView(txaAfvoer);

        javax.swing.GroupLayout pnlAdOutputLayout = new javax.swing.GroupLayout(pnlAdOutput);
        pnlAdOutput.setLayout(pnlAdOutputLayout);
        pnlAdOutputLayout.setHorizontalGroup(
            pnlAdOutputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAdOutputLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        pnlAdOutputLayout.setVerticalGroup(
            pnlAdOutputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAdOutputLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout pnlVr1_1Layout = new javax.swing.GroupLayout(pnlVr1_1);
        pnlVr1_1.setLayout(pnlVr1_1Layout);
        pnlVr1_1Layout.setHorizontalGroup(
            pnlVr1_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVr1_1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlVr1_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlAdvertisement, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlAdOutput, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnlVr1_1Layout.setVerticalGroup(
            pnlVr1_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVr1_1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(pnlAdvertisement, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlAdOutput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        tbpQuestion1.addTab("Advertensie", pnlVr1_1);

        pnlMetodeOpknapping.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true), "Kies die tipe opknapping:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N

        buttonGroup1.add(rbtVerf);
        rbtVerf.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        rbtVerf.setText("Verfwerk");
        rbtVerf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtVerfActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbtTeel);
        rbtTeel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        rbtTeel.setText("Teelwerk");
        rbtTeel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtTeelActionPerformed(evt);
            }
        });

        btnBerekOpknapping.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBerekOpknapping.setText("Bereken en vertoon opknappingskoste");
        btnBerekOpknapping.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBerekOpknappingActionPerformed(evt);
            }
        });

        txaAfvoerOpknapping.setColumns(20);
        txaAfvoerOpknapping.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txaAfvoerOpknapping.setRows(5);
        jScrollPane2.setViewportView(txaAfvoerOpknapping);

        javax.swing.GroupLayout pnlMetodeOpknappingLayout = new javax.swing.GroupLayout(pnlMetodeOpknapping);
        pnlMetodeOpknapping.setLayout(pnlMetodeOpknappingLayout);
        pnlMetodeOpknappingLayout.setHorizontalGroup(
            pnlMetodeOpknappingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMetodeOpknappingLayout.createSequentialGroup()
                .addGroup(pnlMetodeOpknappingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlMetodeOpknappingLayout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addGroup(pnlMetodeOpknappingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnBerekOpknapping, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMetodeOpknappingLayout.createSequentialGroup()
                                .addComponent(rbtVerf)
                                .addGap(124, 124, 124)
                                .addComponent(rbtTeel, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(pnlMetodeOpknappingLayout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlMetodeOpknappingLayout.setVerticalGroup(
            pnlMetodeOpknappingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMetodeOpknappingLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(pnlMetodeOpknappingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbtVerf)
                    .addComponent(rbtTeel))
                .addGap(26, 26, 26)
                .addComponent(btnBerekOpknapping, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 189, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlOppvToevoer.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true), "Oppervlakte wat opgeknap moet word in vierkante meter", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N

        jLabel14.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vraag1Package/meter1.png"))); // NOI18N

        lblOppvOpknap.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblOppvOpknap.setText("Sleutel die oppervlakte wat opgeknap moet word, in:");

        txfOppervlakte.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        javax.swing.GroupLayout pnlOppvToevoerLayout = new javax.swing.GroupLayout(pnlOppvToevoer);
        pnlOppvToevoer.setLayout(pnlOppvToevoerLayout);
        pnlOppvToevoerLayout.setHorizontalGroup(
            pnlOppvToevoerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlOppvToevoerLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(lblOppvOpknap, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txfOppervlakte, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14)
                .addContainerGap(65, Short.MAX_VALUE))
        );
        pnlOppvToevoerLayout.setVerticalGroup(
            pnlOppvToevoerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlOppvToevoerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlOppvToevoerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlOppvToevoerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblOppvOpknap, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txfOppervlakte, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel14))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnlVr1_2Layout = new javax.swing.GroupLayout(pnlVr1_2);
        pnlVr1_2.setLayout(pnlVr1_2Layout);
        pnlVr1_2Layout.setHorizontalGroup(
            pnlVr1_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVr1_2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(pnlVr1_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pnlMetodeOpknapping, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlOppvToevoer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        pnlVr1_2Layout.setVerticalGroup(
            pnlVr1_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVr1_2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlOppvToevoer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pnlMetodeOpknapping, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        tbpQuestion1.addTab("Woonkamer-opknapping", pnlVr1_2);

        pnlBerekenElekt.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true), "Bereken elektrisiteit wat gebruik is", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N

        lblElektrisiteit.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblElektrisiteit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblElektrisiteit.setText("0.00");

        lblVorigeLesing.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblVorigeLesing.setText("Vorige lesing");

        lblHuidigeLesing.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblHuidigeLesing.setText("Huidige lesing");

        txfHudige.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        txfVorige.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txfVorige.setText("2100");

        lblOpskrifKiloW.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblOpskrifKiloW.setText("Elektrisiteitverbruik in kilowatt:");

        lblBedragVerskuldig.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblBedragVerskuldig.setText("Bedrag verskuldig");

        btnBerekenBedrag.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBerekenBedrag.setText("Bereken bedrag verskuldig");
        btnBerekenBedrag.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBerekenBedragActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlBerekenElektLayout = new javax.swing.GroupLayout(pnlBerekenElekt);
        pnlBerekenElekt.setLayout(pnlBerekenElektLayout);
        pnlBerekenElektLayout.setHorizontalGroup(
            pnlBerekenElektLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBerekenElektLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlBerekenElektLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlBerekenElektLayout.createSequentialGroup()
                        .addComponent(lblOpskrifKiloW, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(pnlBerekenElektLayout.createSequentialGroup()
                        .addGroup(pnlBerekenElektLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblVorigeLesing, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txfVorige, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlBerekenElektLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlBerekenElektLayout.createSequentialGroup()
                                .addComponent(txfHudige, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(39, 39, 39)
                                .addComponent(btnBerekenBedrag, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(46, 46, 46)
                                .addComponent(lblElektrisiteit, javax.swing.GroupLayout.DEFAULT_SIZE, 69, Short.MAX_VALUE))
                            .addGroup(pnlBerekenElektLayout.createSequentialGroup()
                                .addComponent(lblHuidigeLesing, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblBedragVerskuldig)))))
                .addContainerGap())
        );
        pnlBerekenElektLayout.setVerticalGroup(
            pnlBerekenElektLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBerekenElektLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblOpskrifKiloW, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addGroup(pnlBerekenElektLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblVorigeLesing, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblHuidigeLesing, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblBedragVerskuldig))
                .addGap(11, 11, 11)
                .addGroup(pnlBerekenElektLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txfVorige, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txfHudige, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblElektrisiteit, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBerekenBedrag, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13))
        );

        pnlGeiserOpsies.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true), "Songeiser-opsies:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N

        txfGeiserGrootte.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txfGeiserGrootte.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txfGeiserGrootte.setText(" ");

        lblGeiserGroottes.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblGeiserGroottes.setText("Sleutel grootte van geiser in (50, 100, 150)");

        javax.swing.GroupLayout pnlGeiserOpsiesLayout = new javax.swing.GroupLayout(pnlGeiserOpsies);
        pnlGeiserOpsies.setLayout(pnlGeiserOpsiesLayout);
        pnlGeiserOpsiesLayout.setHorizontalGroup(
            pnlGeiserOpsiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlGeiserOpsiesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblGeiserGroottes)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txfGeiserGrootte, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlGeiserOpsiesLayout.setVerticalGroup(
            pnlGeiserOpsiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlGeiserOpsiesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlGeiserOpsiesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblGeiserGroottes)
                    .addComponent(txfGeiserGrootte, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        txaAfvoerGeisers.setColumns(20);
        txaAfvoerGeisers.setRows(5);
        jScrollPane3.setViewportView(txaAfvoerGeisers);

        btnVindGeisers.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnVindGeisers.setText("Lys geisers");
        btnVindGeisers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVindGeisersActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlQ1_3Layout = new javax.swing.GroupLayout(pnlQ1_3);
        pnlQ1_3.setLayout(pnlQ1_3Layout);
        pnlQ1_3Layout.setHorizontalGroup(
            pnlQ1_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQ1_3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlQ1_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ1_3Layout.createSequentialGroup()
                        .addGroup(pnlQ1_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pnlGeiserOpsies, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(pnlBerekenElekt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ1_3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(pnlQ1_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnVindGeisers, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(170, 170, 170))))
        );
        pnlQ1_3Layout.setVerticalGroup(
            pnlQ1_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQ1_3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlBerekenElekt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pnlGeiserOpsies, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnVindGeisers, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 142, Short.MAX_VALUE)
                .addContainerGap())
        );

        tbpQuestion1.addTab("Water en elektrisiteit", pnlQ1_3);

        btnClose.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnClose.setText("Close");
        btnClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCloseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnClose))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tbpQuestion1, javax.swing.GroupLayout.PREFERRED_SIZE, 624, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tbpQuestion1, javax.swing.GroupLayout.PREFERRED_SIZE, 519, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(btnClose))
        );

        getAccessibleContext().setAccessibleName("aa");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVerkoopsAdvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerkoopsAdvActionPerformed
        double mark = Double.parseDouble(txfMarkwaarde.getText());
        double verkoop = Double.parseDouble(txfVerkoopsprys.getText());
        String bed = txfBeddens.getText();
        String badkamer = txfBadkamers.getText();
        String advertensie = "R" + (int)(verkoop) + "#" + bed + "Bed#" + badkamer + "Bad#";
        if (chkSwembad.isSelected()) {
            advertensie += "Swembad#";
        }
        if (verkoop < mark) {
            advertensie += "Winskoop";
        }
        txaAfvoer.setText("Huis te koop:\n");
        txaAfvoer.append(advertensie);
    }//GEN-LAST:event_btnVerkoopsAdvActionPerformed

    private void btnVindGeisersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVindGeisersActionPerformed
        String geiserGrootte = txfGeiserGrootte.getText().trim();
        txaAfvoerGeisers.setText("");
        for (int i = 0; i < arrGeisers.length; i++) {
            int psnDash = arrGeisers[i].indexOf("-");
            String grootte = arrGeisers[i].substring(0, psnDash);
            if (grootte.equals(geiserGrootte)) {
                txaAfvoerGeisers.append(arrGeisers[i].substring(psnDash + 1) + "\n");
            }
        }
    }//GEN-LAST:event_btnVindGeisersActionPerformed

    private void rbtVerfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtVerfActionPerformed
        opknappingsTipe = 'V';
    }//GEN-LAST:event_rbtVerfActionPerformed

    private void rbtTeelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtTeelActionPerformed
        opknappingsTipe = 'T';
    }//GEN-LAST:event_rbtTeelActionPerformed

    private void btnBerekOpknappingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBerekOpknappingActionPerformed
        int aantEenLiterDrom = 0;
        int aantTweeLiterDrom = 0;
        int aantVyfLiterDrom = 0;
        double koste = 0.0;
        double oppervlakte = Double.parseDouble(txfOppervlakte.getText());
        if (opknappingsTipe == 'V') {
            double aantLiterVerf = oppervlakte / 8;
            int volumeLiter = (int) (Math.round(aantLiterVerf + 0.4));
            if (volumeLiter / 5 > 0) {
                aantVyfLiterDrom += (int) (volumeLiter / 5);
                volumeLiter -= aantVyfLiterDrom * 5;
                koste += aantVyfLiterDrom * 199;
            }
            if (volumeLiter / 2 > 0) {
                aantTweeLiterDrom += (int) (volumeLiter / 2);
                volumeLiter -= aantTweeLiterDrom * 2;
                koste += aantTweeLiterDrom * 92.30;
            }
            aantEenLiterDrom = volumeLiter;
            koste += aantEenLiterDrom * 55.50;
            
            txaAfvoerOpknapping.setText("Oppervlakte: " + (int)(oppervlakte) + " vierkante meter");
            txaAfvoerOpknapping.append("\nVolume verf wat benodig word: " + aantLiterVerf + " liter");
            txaAfvoerOpknapping.append("\n\n1 liter-dromme: " + aantEenLiterDrom);
            txaAfvoerOpknapping.append("\n2 liter-dromme: " + aantTweeLiterDrom);
            txaAfvoerOpknapping.append("\n5 liter-dromme: " + aantVyfLiterDrom);
            txaAfvoerOpknapping.append("\n\nTotale koste: " + df.format(koste));
        }
        if (opknappingsTipe == 'T') {
            double teelKoste = Double.parseDouble(JOptionPane.showInputDialog("Sleutel die koste per vierkante meter in"));
            koste = (oppervlakte + 5) * teelKoste;
            txaAfvoerOpknapping.setText("Oppervlakte: " + Math.round(oppervlakte) + " vierkante meter" + "\nTotale koste: " + df.format(koste));
        }
    }//GEN-LAST:event_btnBerekOpknappingActionPerformed

    private void btnBerekenBedragActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBerekenBedragActionPerformed
        int vorigeLesing = 0;
        int huidigeLesing = 0;
        double eletrRekening = 0;
        vorigeLesing = Integer.parseInt(txfVorige.getText());
        huidigeLesing = Integer.parseInt(txfHudige.getText());
        if (vorigeLesing > huidigeLesing) {
            JOptionPane.showMessageDialog(null, "Vorige lesing is groter as huidige lesing, sleutel weer in");
            txfHudige.setText("0");
        } else {
            int elektrGebruik = huidigeLesing - vorigeLesing;
            if (elektrGebruik <= 600) {
                eletrRekening = elektrGebruik;
            } else {
                eletrRekening = 600 + ((elektrGebruik - 600) * 1.5);
            }
        }
        lblElektrisiteit.setText(df.format(eletrRekening));
    }//GEN-LAST:event_btnBerekenBedragActionPerformed

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnCloseActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vraag1_Memo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vraag1_Memo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vraag1_Memo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vraag1_Memo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vraag1_Memo().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBerekOpknapping;
    private javax.swing.JButton btnBerekenBedrag;
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnVerkoopsAdv;
    private javax.swing.JButton btnVindGeisers;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JCheckBox chkSwembad;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblAantalBadkamers;
    private javax.swing.JLabel lblAantalSlaapkamers;
    private javax.swing.JLabel lblBedragVerskuldig;
    private javax.swing.JLabel lblElektrisiteit;
    private javax.swing.JLabel lblGeiserGroottes;
    private javax.swing.JLabel lblHuidigeLesing;
    private javax.swing.JLabel lblMarkwaarde;
    private javax.swing.JLabel lblOppvOpknap;
    private javax.swing.JLabel lblOpskrifKiloW;
    private javax.swing.JLabel lblVerkoopsprys;
    private javax.swing.JLabel lblVorigeLesing;
    private javax.swing.JPanel pnlAdOutput;
    private javax.swing.JPanel pnlAdvertisement;
    private javax.swing.JPanel pnlBerekenElekt;
    private javax.swing.JPanel pnlGeiserOpsies;
    private javax.swing.JPanel pnlMetodeOpknapping;
    private javax.swing.JPanel pnlOppvToevoer;
    private javax.swing.JPanel pnlQ1_3;
    private javax.swing.JPanel pnlVr1_1;
    private javax.swing.JPanel pnlVr1_2;
    private javax.swing.JRadioButton rbtTeel;
    private javax.swing.JRadioButton rbtVerf;
    private javax.swing.JTabbedPane tbpQuestion1;
    private javax.swing.JTextArea txaAfvoer;
    private javax.swing.JTextArea txaAfvoerGeisers;
    private javax.swing.JTextArea txaAfvoerOpknapping;
    private javax.swing.JTextField txfBadkamers;
    private javax.swing.JTextField txfBeddens;
    private javax.swing.JTextField txfGeiserGrootte;
    private javax.swing.JTextField txfHudige;
    private javax.swing.JTextField txfMarkwaarde;
    private javax.swing.JTextField txfOppervlakte;
    private javax.swing.JTextField txfVerkoopsprys;
    private javax.swing.JTextField txfVorige;
    // End of variables declaration//GEN-END:variables
    String[] arrGeisers = {"50-QuickSun50", "100-QuickSun100", "150-QuickSun150", "50-Solar Magic", "50-InHotWater",
        "100-SunnyBath 100", "150-SunnyBath 150", "50-WaterJoy 50", "100-WaterJoy 100",
        "150-BigTub 150", "50-Small Wonder", "100-Medium Wonder", "150-Large Wonder",
        "100-SolarWarmth 100", "150-SolarWarmth 150", "50-Sun Magic", "50-Eco Wonder 50",
        "100-Eco Wonder 100", "150-Eco Wonder 150", "150-Big Earth Saver"};
}
