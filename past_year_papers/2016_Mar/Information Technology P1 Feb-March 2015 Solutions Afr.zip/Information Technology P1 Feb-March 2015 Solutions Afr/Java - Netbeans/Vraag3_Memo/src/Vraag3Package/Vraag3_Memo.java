//
// Oplossing vir vraag 3
//

package Vraag3Package;

public class Vraag3_Memo extends javax.swing.JFrame {

    // Given code
    VulSkikkings objAssign = new VulSkikkings();
  
    String[] arrVerkope = objAssign.populateArrVerkope();
    String[] arrAgente = objAssign.populateArrAgente();
    // Nuwe kode
    String agentKode = "";
    String agentNaam = "";
    String[] arrTipes = {"Kommersieel", "Resedensieel", "Landbou"};
    String[] arrMaande = {"Jan", "Feb", "Mrt", "Apr", "Mei", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Des"};
   
    public Vraag3_Memo() {
        initComponents();
        setLocationRelativeTo(this);      
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        pnlContent = new javax.swing.JPanel();
        pnlVerkoopBesonderhede = new javax.swing.JPanel();
        lblAgentCode = new javax.swing.JLabel();
        btnAgentNaam = new javax.swing.JButton();
        lblAgentNaam = new javax.swing.JLabel();
        btnAgentVerkope = new javax.swing.JButton();
        txfAgentKode = new javax.swing.JTextField();
        pnlAfvoer = new javax.swing.JPanel();
        lblTotaal = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txaV3 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Question3 - Solution");

        pnlVerkoopBesonderhede.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true), "Agent se besonderhede van aankope", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N

        lblAgentCode.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblAgentCode.setText("Sleutel agent se kode in");

        btnAgentNaam.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnAgentNaam.setText("Vind agent se naam");
        btnAgentNaam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgentNaamActionPerformed(evt);
            }
        });

        lblAgentNaam.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        btnAgentVerkope.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnAgentVerkope.setText("Agent se verkope");
        btnAgentVerkope.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgentVerkopeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlVerkoopBesonderhedeLayout = new javax.swing.GroupLayout(pnlVerkoopBesonderhede);
        pnlVerkoopBesonderhede.setLayout(pnlVerkoopBesonderhedeLayout);
        pnlVerkoopBesonderhedeLayout.setHorizontalGroup(
            pnlVerkoopBesonderhedeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVerkoopBesonderhedeLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlVerkoopBesonderhedeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblAgentCode)
                    .addComponent(txfAgentKode, javax.swing.GroupLayout.DEFAULT_SIZE, 224, Short.MAX_VALUE)
                    .addComponent(lblAgentNaam, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 315, Short.MAX_VALUE)
                .addGroup(pnlVerkoopBesonderhedeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnAgentNaam, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAgentVerkope, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(35, 35, 35))
        );
        pnlVerkoopBesonderhedeLayout.setVerticalGroup(
            pnlVerkoopBesonderhedeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlVerkoopBesonderhedeLayout.createSequentialGroup()
                .addGroup(pnlVerkoopBesonderhedeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlVerkoopBesonderhedeLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblAgentCode)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txfAgentKode, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlVerkoopBesonderhedeLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(btnAgentNaam, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlVerkoopBesonderhedeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAgentVerkope, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAgentNaam, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlAfvoer.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true), "Vertoon-area", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N

        lblTotaal.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        txaV3.setColumns(20);
        txaV3.setFont(new java.awt.Font("Monospaced", 1, 12)); // NOI18N
        txaV3.setRows(5);
        jScrollPane2.setViewportView(txaV3);

        javax.swing.GroupLayout pnlAfvoerLayout = new javax.swing.GroupLayout(pnlAfvoer);
        pnlAfvoer.setLayout(pnlAfvoerLayout);
        pnlAfvoerLayout.setHorizontalGroup(
            pnlAfvoerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAfvoerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlAfvoerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(pnlAfvoerLayout.createSequentialGroup()
                        .addComponent(lblTotaal, javax.swing.GroupLayout.PREFERRED_SIZE, 496, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 209, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pnlAfvoerLayout.setVerticalGroup(
            pnlAfvoerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAfvoerLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTotaal, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout pnlContentLayout = new javax.swing.GroupLayout(pnlContent);
        pnlContent.setLayout(pnlContentLayout);
        pnlContentLayout.setHorizontalGroup(
            pnlContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlContentLayout.createSequentialGroup()
                .addGroup(pnlContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlVerkoopBesonderhede, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlAfvoer, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnlContentLayout.setVerticalGroup(
            pnlContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlContentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlVerkoopBesonderhede, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pnlAfvoer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jButton1.setText("Verlaat");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlContent, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(36, 36, 36))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlContent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgentNaamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgentNaamActionPerformed
        txaV3.setText("");
        agentKode = txfAgentKode.getText();

        boolean gevind = false;
        int p = 0;

        while (!gevind && p < arrAgente.length) {
            if (arrAgente[p].substring(0, 4).equals(agentKode)) {
                agentNaam = arrAgente[p].substring(arrAgente[p].indexOf(":") + 1);
                lblAgentNaam.setText(agentNaam);
                gevind = true;
            }
            p++;
        }
        if (!gevind) {
            lblAgentNaam.setText("Ongeldige agentkode");
            txfAgentKode.setText("");
        }
    }//GEN-LAST:event_btnAgentNaamActionPerformed

    private void btnAgentVerkopeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgentVerkopeActionPerformed
        btnAgentNaam.doClick();
        initVerkope();
            int totaal = 0;
            for (int i = 0; i < arrVerkope.length; i++) {
                if (arrVerkope[i].substring(5, 9).equals(agentKode)) {
                    int maand = Integer.parseInt(arrVerkope[i].substring(0, 2));
                    int kol = maand - 1;
                    char temp = arrVerkope[i].charAt(3);
                    int ry = 0;
                    switch (temp) {
                        case 'K':
                            ry = 0;
                            break;
                        case 'R':
                            ry = 1;
                            break;
                        case 'L':
                            ry = 2;
                            break;
                    }
                    arrAgentVerkope[ry][kol]++;
                    arrAgentVerkope[ry][12] += 1;
                   
                    totaal += Integer.parseInt(arrVerkope[i].substring(arrVerkope[i].indexOf(";") + 1));                                       
                }
            }
            
            //Vertoon in teksarea
            txaV3.setText(String.format("%-13s", ""));
            for (int i = 0; i < 12; i++) {
                txaV3.append(String.format("%-4s", arrMaande[i]));
            }
            txaV3.append("\n\n");
            for (int r = 0; r < 3; r++) {
                txaV3.append(String.format("%-13s", arrTipes[r]));
                
                for (int c = 0; c < 13; c++) {
                    txaV3.append(String.format("%-4s", arrAgentVerkope[r][c]));
                }
                txaV3.append("\n\n");
            }
            txaV3.append("Totale waarde van verkope: R " + totaal);
        
           //Vertoon op grid
            
            
    }//GEN-LAST:event_btnAgentVerkopeActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        System.exit(0);
        
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vraag3_Memo().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgentNaam;
    private javax.swing.JButton btnAgentVerkope;
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel lblAgentCode;
    private javax.swing.JLabel lblAgentNaam;
    private javax.swing.JLabel lblTotaal;
    private javax.swing.JPanel pnlAfvoer;
    private javax.swing.JPanel pnlContent;
    private javax.swing.JPanel pnlVerkoopBesonderhede;
    private javax.swing.JTextArea txaV3;
    private javax.swing.JTextField txfAgentKode;
    // End of variables declaration//GEN-END:variables

    public void initVerkope() {
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 13; c++) {
                arrAgentVerkope[r][c] = 0;
            }
        }
    }
    int[][] arrAgentVerkope = new int[3][13];
}
