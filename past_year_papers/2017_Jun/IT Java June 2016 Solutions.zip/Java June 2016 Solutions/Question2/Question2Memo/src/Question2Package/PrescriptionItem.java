/*
 * Possible solution for Q2.1
 */
package Question2Package;


public class PrescriptionItem {

    private String code;
    private String dosage;
    private int days;
    private double price;

    public PrescriptionItem(String code, String dosage, int days, double price) {
        this.code = code;
        this.dosage = dosage;
        this.days = days;
        this.price = price;
    }
/// 2.1.2
    public int calcTabletsPerDay() {
        int numTabletsPerDay = 0;

        if (dosage.charAt(0) == ('D')) {
            numTabletsPerDay = Integer.parseInt(dosage.substring(1, 2));
        }
        if (dosage.charAt(0) == ('H')) {
            String[] temp = dosage.split("#");
            numTabletsPerDay = Integer.parseInt(dosage.substring(1, 2)) * 24 / Integer.parseInt(temp[1]);
        }
        return numTabletsPerDay;
    }
    //2.1.3
    public String compileFrequencyOfUseMessage() {
        String message = "";
        if(dosage.charAt(0)=='D') 
        {
                if (code.charAt(3) == 'B') {
                    message = "Take "+ dosage.charAt(1)+" tablet(s) daily after breakfast";
                }
                else
                {
                    message = "Take "+ dosage.charAt(1)+" tablet(s) daily after supper";
                }
         }
        else
        {
           message = "Take " + dosage.charAt(1) + " tablet(s) every " + dosage.charAt(3) + " hours";  
        }
        return message;
    }

    // 2.1.4
    public int calcTotalNumTablets() {
        return  calcTabletsPerDay() * days;
    }

    // 2.1.5
    public String getCode() {
        return code;
    }

    public double getPrice() {
        return price;
    }
    
    // 2.1.6
    public String compileLabel() {
        return "Tablet code: " + code + "\n\n" + compileFrequencyOfUseMessage() + " for " + days + " days. \n\n(" + calcTotalNumTablets() + " tablets)";
    }
}
